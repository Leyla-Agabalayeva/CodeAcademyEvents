﻿using AutoMapper;
using CodeAcademyEvents.BLL.DTOs;
using CodeAcademyEvents.BLL.Services.Interfaces;
using CodeAcademyEvents.DAL.Entities;
using CodeAcademyEvents.DAL.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Net;
using System.Net.Mail;

namespace CodeAcademyEvents.BLL.Services.Implementations
{
    public class NotificationService : INotificationService
    {
        private readonly IUnitOfWork _uow;
        private readonly IEmailSender _emailSender;

        public NotificationService(IUnitOfWork uow, IEmailSender emailSender)
        {
            _uow = uow;
            _emailSender = emailSender;
        }

        public async Task SendEventReminderAsync(int eventId, string message)
        {
            var notification = new Notification
            {
                EventId = eventId,
                Message = message,
                SentAt = DateTime.Now
            };
            await _uow.Notifications.AddAsync(notification);
            await _uow.SaveChangesAsync();

            // Yalnız dəvəti qəbul edənlərə bildiriş göndər
            var acceptedInvitations = await _uow.Invitations.GetAll()
                .Include(i => i.Person)
                .Where(i => i.EventId == eventId && i.Status == InvitationStatus.Accepted)
                .ToListAsync();

            foreach (var inv in acceptedInvitations)
            {
                await _emailSender.SendEmailAsync(inv.Person.Email, "Tədbir Xatırlatması", message);
            }
        }
    }

    public class FeedbackService : IFeedbackService
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;

        public FeedbackService(IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
        }

        public async Task SubmitAsync(FeedbackDto dto)
        {
            if (dto.Rating < 1 || dto.Rating > 5)
                throw new ArgumentOutOfRangeException(nameof(dto.Rating), "Reytinq 1-5 aralığında olmalıdır.");

            var feedback = _mapper.Map<Feedback>(dto);
            feedback.SubmittedAt = DateTime.Now;
            await _uow.Feedbacks.AddAsync(feedback);
            await _uow.SaveChangesAsync();
        }

        public async Task<List<FeedbackDto>> GetByEventIdAsync(int eventId)
        {
            var list = await _uow.Feedbacks.GetAll()
                .Where(f => f.EventId == eventId)
                .ToListAsync();

            return _mapper.Map<List<FeedbackDto>>(list);
        }
    }

    public class StatisticsService : IStatisticsService
    {
        private readonly IUnitOfWork _uow;

        public StatisticsService(IUnitOfWork uow)
        {
            _uow = uow;
        }

        public async Task<EventStatisticsDto> GetEventStatisticsAsync(int eventId)
        {
            var ev = await _uow.Events.GetByIdAsync(eventId);
            var invitations = await _uow.Invitations.GetAll()
                .Where(i => i.EventId == eventId)
                .ToListAsync();

            var checkedInCount = await _uow.Participations.GetAll()
                .Include(p => p.Invitation)
                .CountAsync(p => p.Invitation.EventId == eventId && p.CheckInTime != null);

            var feedbacks = await _uow.Feedbacks.GetAll()
                .Where(f => f.EventId == eventId)
                .ToListAsync();

            return new EventStatisticsDto
            {
                EventId = eventId,
                EventTitle = ev?.Title ?? "",
                TotalInvited = invitations.Count,
                TotalAccepted = invitations.Count(i => i.Status == InvitationStatus.Accepted),
                TotalRejected = invitations.Count(i => i.Status == InvitationStatus.Rejected),
                TotalCheckedIn = checkedInCount,
                FeedbackCount = feedbacks.Count,
                AverageRating = feedbacks.Any() ? Math.Round(feedbacks.Average(f => f.Rating), 2) : 0
            };
        }
    }

    // SMTP ilə email göndərmə (appsettings.json-dan konfiqurasiya oxunur)
    public class EmailSender : IEmailSender
    {
        private readonly IConfiguration _config;

        public EmailSender(IConfiguration config)
        {
            _config = config;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            var smtpSection = _config.GetSection("SmtpSettings");
            var host = smtpSection["Host"];
            var port = int.Parse(smtpSection["Port"] ?? "587");
            var username = smtpSection["Username"];
            var password = smtpSection["Password"];
            var from = smtpSection["From"];

            using var client = new SmtpClient(host, port)
            {
                Credentials = new NetworkCredential(username, password),
                EnableSsl = true
            };

            var mail = new MailMessage(from!, toEmail, subject, body);
            await client.SendMailAsync(mail);
        }
    }

}
